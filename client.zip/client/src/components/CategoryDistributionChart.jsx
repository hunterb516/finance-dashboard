import { Doughnut } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
ChartJS.register(ArcElement, Tooltip, Legend)

export default function CategoryDistributionChart({ items }){
  const data = {
    labels: items.map(i=>i.category),
    datasets: [ { data: items.map(i=>Number(i.total)) } ]
  }
  return <Doughnut data={data} />
}
