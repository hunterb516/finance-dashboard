import { Bar } from 'react-chartjs-2'
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js'
ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend)

export default function SavingsProgressChart({ value, target=5000 }){
  const data = {
    labels: ['Savings'],
    datasets: [ { label: 'YTD', data: [Number(value)] }, { label: 'Goal', data: [Number(target)] } ]
  }
  return <Bar data={data} />
}
