import { Line } from 'react-chartjs-2'
import { Chart as ChartJS, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend } from 'chart.js'
ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend)

export default function MonthlySpendingChart({ items }){
  const labels = items.map(i=>i.month)
  const data = {
    labels,
    datasets: [
      { label: 'Income', data: items.map(i=>Number(i.income)) },
      { label: 'Expenses', data: items.map(i=>Number(i.expenses)) },
    ]
  }
  return <Line data={data} />
}
