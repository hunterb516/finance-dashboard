import { useEffect, useState } from 'react'
import api from '../api'
import MonthlySpendingChart from "../components/MonthlySpendingChart,jsx"
import CategoryDistributionChart from "../components/CategoryDistributionChart.jsx"
import SavingsProgressChart from "../components/SavingsProgressChart.jsx"

export default function Dashboard() {
  const [monthly, setMonthly] = useState([])
  const [categories, setCategories] = useState([])
  const [savings, setSavings] = useState({ goal: 0, saved: 0 })
  const [err, setErr] = useState('')

  useEffect(() => {
    let mounted = true

    async function load() {
      setErr('')
      try {
        // IMPORTANT: use api.get so Authorization header is attached
        const [m, c, s] = await Promise.all([
          api.get('/api/analytics/monthly'),
          api.get('/api/analytics/categories'),
          api.get('/api/analytics/savings'),
        ])
        if (!mounted) return
        setMonthly(m.data.items || [])
        setCategories(c.data.items || [])
        setSavings(s.data || { goal: 0, saved: 0 })
      } catch (e) {
        console.error('Dashboard load error:', e)
        setErr('Failed to load analytics. Are you logged in?')
      }
    }

    load()
    return () => { mounted = false }
  }, [])

  return (
    <div style={{ display:'grid', gap:16 }}>
      <h2>Dashboard</h2>
      {err && <div style={{ color:'red' }}>{err}</div>}
      <MonthlySpendingChart data={monthly} />
      <CategoryDistributionChart data={categories} />
      <SavingsProgressChart goal={savings.goal} saved={savings.saved} />
    </div>
  )
}
