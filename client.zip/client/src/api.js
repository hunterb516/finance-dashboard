import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:5000',
  withCredentials: true,
})

// ---------- token helpers ----------
export function setTokens({ access, refresh }) {
  if (access) {
    localStorage.setItem('token', access)
    api.defaults.headers.common['Authorization'] = `Bearer ${access}`
  }
  if (refresh) {
    localStorage.setItem('refresh_token', refresh)
  }
}

export function clearTokens() {
  localStorage.removeItem('token')
  localStorage.removeItem('refresh_token')
  delete api.defaults.headers.common['Authorization']
}

// set header on first load if we already have an access token
const saved = localStorage.getItem('token')
if (saved) {
  api.defaults.headers.common['Authorization'] = `Bearer ${saved}`
}

// ---------- refresh-on-401 ----------
let isRefreshing = false
let queue = []

function resolveQueue(newAccess) {
  queue.forEach(cb => cb(newAccess))
  queue = []
}

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config

    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const refresh = localStorage.getItem('refresh_token')
      if (!refresh) {
        clearTokens()
        return Promise.reject(error)
      }

      if (isRefreshing) {
        // wait until current refresh finishes
        return new Promise((resolve) => {
          queue.push((newAccess) => {
            original.headers.Authorization = `Bearer ${newAccess}`
            resolve(api(original))
          })
        })
      }

      isRefreshing = true
      try {
        // bare axios avoids looping this interceptor
        const r = await axios.post('http://localhost:5000/api/auth/refresh', null, {
          headers: { Authorization: `Bearer ${refresh}` },
          withCredentials: true,
        })
        const newAccess = r.data.access_token
        setTokens({ access: newAccess })
        isRefreshing = false
        resolveQueue(newAccess)

        original.headers.Authorization = `Bearer ${newAccess}`
        return api(original)
      } catch (e) {
        isRefreshing = false
        clearTokens()
        return Promise.reject(e)
      }
    }

    return Promise.reject(error)
  }
)

export default api
